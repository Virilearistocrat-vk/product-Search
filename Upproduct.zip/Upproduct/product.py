from flask import Flask, render_template, request,url_for

import sqlite3 as sql
app = Flask(__name__)

@app.route('/')
def home():
   return render_template('home.html')

@app.route('/enternew')
def new_product():
   return render_template('product.html')

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
   if request.method == 'POST':
      try:
         pid=request.form['pid']
         pname = request.form['pname']
         manufacturer = request.form['manufacturer']
         category = request.form['category']
         price = request.form['price']
         color = request.form['color']
         qtyavbl = request.form['qtyavbl']
         size = request.form['size']
         
         with sql.connect("Uproduct.db") as con:
            cur = con.cursor()
            
            cur.execute("INSERT INTO Uproduct (pid,pname,manufacturer,category,price,color,qtyavbl,size) VALUES (?,?,?,?,?,?,?,?)",(pid,pname,manufacturer,category,price,color,qtyavbl,size) )
            
            con.commit()
            msg = "Record successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         return render_template("result.html",msg = msg)
         con.close()

@app.route('/list')
def list():
   con = sql.connect("Uproduct.db")
   con.row_factory = sql.Row
   
   cur = con.cursor()
   cur.execute("select * from Uproduct")
   
   rows = cur.fetchall();
   return render_template("list.html",rows = rows)

if __name__ == '__main__':
   app.run(debug = True)