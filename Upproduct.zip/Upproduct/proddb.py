import sqlite3

conn = sqlite3.connect('Uproduct.db')
print ("Opened database successfully");

conn.execute('CREATE TABLE uproduct (pid integer ,pname TEXT not null, manufacturer TEXT not null, category TEXT not null, price integer not null,color text not null,qtyavbl integer not null,size text )')
print ("Table created successfully");
conn.close()